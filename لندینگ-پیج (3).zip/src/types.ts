export type UserRole = 'teacher' | 'student' | 'manager';

export type AuthMode = 'password' | 'otp';

export interface ToastMessage {
  id: string;
  type: 'info' | 'success' | 'error' | 'sms';
  title: string;
  message: string;
  code?: string;
}

export interface LoginFormData {
  role: UserRole;
  authMode: AuthMode;
  username: string; // Mobile or National ID
  password?: string;
  otpCode?: string;
  captchaInput: string;
  rememberMe: boolean;
}
